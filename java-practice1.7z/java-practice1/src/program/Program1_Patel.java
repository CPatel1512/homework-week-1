

public class Program1_Patel {

    public static void main(String[] args) {

        System.out.println("              BIODATA                             ");


        System.out.println("Name                      Chetan Patel");

        System.out.println("Gender                     Male      ");


        System.out.println("Date of Birth            15/12/1981");


        System.out.println("Religion                  Hindu");

        System.out.println("Nature                    Well mannered");

        System.out.println("Hobbies                   Reading and Playing");

        System.out.println("Education                  Bsc(Biochem)");

        System.out.println("Father's name             Mahendrabhai");

        System.out.println("Mothers name              Jagrutiben");


        System.out.println("Adress                     302 High street ,Sutton ");
        System.out.println("                           Post code- SM11PQ        ");

        System.out.println("Marital status             Married                   ");
    }
}

