package program;

public class Program3_Patel {

    public static void main(String[] args){

System.out.println("  ******        ************        ************  ");
System.out.println("  **  **                 **         **             ");
System.out.println("  **   **                **         **             ");
System.out.println("  **    **               **         **             ");
System.out.println("  **    **        **     **         ************   ");
System.out.println("  **   **          **    **         **             ");
System.out.println("  **  **            **   **         **             ");
System.out.println("  *****               ****          ************b  ");

    }
    }

