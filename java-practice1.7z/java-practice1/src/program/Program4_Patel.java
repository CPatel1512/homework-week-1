package program;

public class Program4_Patel {

    public static void main(String[] args){
        System.out.println("               *                     ");
        System.out.println("               **                    ");
        System.out.println("               ***                   ");
        System.out.println("               ****                  ");
        System.out.println("               *****                 ");
        System.out.println("               ******                ");


    }

}
