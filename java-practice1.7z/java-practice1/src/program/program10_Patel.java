package program;

public class program10_Patel {

    public static void main(String[] args) {

        System.out.println("        Test Data   ");
        System.out.println("        Input first number : 25 ");
        System.out.println("        Input second number : 5 ");
        System.out.println("        Expected result : 25 x 5 = 125 ");

    }
}
