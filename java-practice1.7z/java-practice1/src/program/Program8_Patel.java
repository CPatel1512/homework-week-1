package program;

public class Program8_Patel {
    public static void main(String[] args) {

        System.out.println("Test Data : 50/3");
        System.out.println("Expected Output : 16");
    }
}
