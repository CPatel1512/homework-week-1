package program;

public class Program7_Patel {
    public static void main(String[] args) {
        System.out.println("Test Data : 74+36");
        System.out.println("Expected Output : 110");
    }
}
