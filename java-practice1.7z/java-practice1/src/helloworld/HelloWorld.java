package helloworld;

public class HelloWorld {

    public  static  void main(String[] args){
        System.out.println("Chetan");
        System.out.println(" Patel");
    }

}
