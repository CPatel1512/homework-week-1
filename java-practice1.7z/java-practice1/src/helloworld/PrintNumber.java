package helloworld;

public class PrintNumber {

    public static void main(String[] args) {

        int a = 10;
        int b = 20;
        String name = "Prime Testing";
        System.out.println(a);
        System.out.println(b);
        System.out.println("a");
        System.out.println(name);
        System.out.println(30);
        System.out.println(10+40);
        System.out.println("10+40");
        System.out.println(a+b);
        System.out.println(a*b);
        System.out.println(a/b);



    }


}
