package datatypes;

public class DataTypes {

    public static void main(String[] args) {
        // byte, short, int, long - for numerical values
        int a = 127;
        int b = 20;
        int result = a + b;
        System.out.println(result);

        //double and  float for decimal value
        double d = 5.54;
        float e = 10.5f;
        System.out.println(d);

        // character - for single character
        char c = 'K';
        System.out.println(c);
        //boolean - for true or false
        boolean myResult = true;
        System.out.println(myResult);

        //String - for a word or statement
        String name = "Prime Testing";
        String myName = "Chetan Patel";
        System.out.println(myName);


    }

}
